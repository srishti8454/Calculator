package com.task.calculator.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.calculator.entity.Calculation;
import com.task.calculator.repository.CalculationRepository;
import com.task.calculator.request.CalculatorRequest;
import com.task.calculator.response.CalculatorResponse;

@Service
public class CalculationService {

	@Autowired
	private  CalculationRepository calculationRepository;

	
	
	
	public CalculatorResponse addition(Calculation calculation) {
		CalculatorRequest calculatorRequest  = new CalculatorRequest();
		CalculatorResponse  calculatorResponse = new CalculatorResponse();
		
		if (calculation.getOperation().equals("Add")) {
		    double finalRes = calculation.getOperand1() + calculation.getOperand2();
	
			calculatorResponse.setResult(finalRes);
			calculatorResponse.setStatusCode("101");
			calculatorResponse.setStatusDescription("Success");
			calculatorRequest.setOperand1(calculatorRequest.getOperand1());
			calculatorRequest.setOperand2(calculatorRequest.getOperand2());
			calculation.setResult(finalRes);			
			calculationRepository.save(calculation);
			
			
		}
		
		return calculatorResponse;
		
	}
	
	
	
	public CalculatorResponse substraction(Calculation calculation) {
		CalculatorRequest calculatorRequest  = new CalculatorRequest();
		CalculatorResponse  calculatorResponse = new CalculatorResponse();
		
		if (calculation.getOperation().equals("Sub")) {
		    double finalRes = calculation.getOperand1() - calculation.getOperand2();
	
			calculatorResponse.setResult(finalRes);
			calculatorResponse.setStatusCode("101");
			calculatorResponse.setStatusDescription("Success");
			calculatorRequest.setOperand1(calculatorRequest.getOperand1());
			calculatorRequest.setOperand2(calculatorRequest.getOperand2());
			calculation.setResult(finalRes);			
			calculationRepository.save(calculation);
			
			
		}
		
		return calculatorResponse;
		
	}
	
	
	public CalculatorResponse multiplication(Calculation calculation) {
		CalculatorRequest calculatorRequest  = new CalculatorRequest();
		CalculatorResponse  calculatorResponse = new CalculatorResponse();
		
		if (calculation.getOperation().equals("Multi")) {
		    double finalRes = calculation.getOperand1() * calculation.getOperand2();
	
			calculatorResponse.setResult(finalRes);
			calculatorResponse.setStatusCode("101");
			calculatorResponse.setStatusDescription("Success");
			calculatorRequest.setOperand1(calculatorRequest.getOperand1());
			calculatorRequest.setOperand2(calculatorRequest.getOperand2());
			calculation.setResult(finalRes);			
			calculationRepository.save(calculation);
			
			
		}
		
		return calculatorResponse;
		
	}
	
	
	public CalculatorResponse division(Calculation calculation) {
		CalculatorRequest calculatorRequest  = new CalculatorRequest();
		CalculatorResponse  calculatorResponse = new CalculatorResponse();
		
		if (calculation.getOperation().equals("Div")) {
		    double finalRes = calculation.getOperand1() / calculation.getOperand2();
	
			calculatorResponse.setResult(finalRes);
			calculatorResponse.setStatusCode("101");
			calculatorResponse.setStatusDescription("Success");
			calculatorRequest.setOperand1(calculatorRequest.getOperand1());
			calculatorRequest.setOperand2(calculatorRequest.getOperand2());
			calculation.setResult(finalRes);			
			calculationRepository.save(calculation);
			
			
		}
		
		return calculatorResponse;
		
	}
	
	
	
	
	
	

}
