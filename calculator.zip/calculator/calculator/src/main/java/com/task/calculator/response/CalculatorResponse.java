package com.task.calculator.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CalculatorResponse {
	
	@JsonProperty("statusCode")
    private String statusCode;

    @JsonProperty("statusDescription")
    private String statusDescription;

    @JsonProperty("result")
    private double result;

	public String getStatusCode() {
		return statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public double getResult() {
		return result;
	}

	public void setResult(double result) {
		this.result = result;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public CalculatorResponse(String statusCode, String statusDescription, double result) {
		super();
		this.statusCode = statusCode;
		this.statusDescription = statusDescription;
		this.result = result;
	}

	public CalculatorResponse() {
		super();
		// TODO Auto-generated constructor stub
	}


	
    
    
	

}
