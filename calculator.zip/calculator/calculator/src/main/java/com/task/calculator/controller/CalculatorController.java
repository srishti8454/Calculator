package com.task.calculator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.task.calculator.entity.Calculation;
import com.task.calculator.request.CalculatorRequest;
import com.task.calculator.response.CalculatorResponse;
import com.task.calculator.service.CalculationService;

@RestController
@RequestMapping("/api/calculator")
public class CalculatorController {
	

	
    private final CalculationService calculationService;

    @Autowired
    public CalculatorController(CalculationService calculationService) {
        this.calculationService = calculationService;
    }

    
    @PostMapping("/calculate")
    public CalculatorResponse getResult(@RequestBody Calculation calculation) throws Exception {
    	CalculatorResponse response = new CalculatorResponse();
        response = calculationService.getResult(calculation);
        return response;

    }
	

    
    
    
    
    
	

}
