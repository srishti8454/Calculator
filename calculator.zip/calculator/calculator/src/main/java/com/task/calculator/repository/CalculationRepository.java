package com.task.calculator.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.task.calculator.entity.Calculation;

public interface CalculationRepository extends JpaRepository<Calculation, Long> {

}
